<?php $__env->startSection('login'); ?>

<h2>Registeration</h2>
<?php echo Form::open(['url'=>'home']); ?>


<?php echo Form::label('username',"Username "); ?>

<?php echo Form::text('username',null,['class'=>'form-control']); ?>


<div>
    <?php echo Form::label('password',"Password "); ?>

<?php echo Form::text('password',null,['class'=>'form-control']); ?>

</div>
    <div>
<?php echo Form::label('email',"Email "); ?>

<?php echo Form::text('email',null,['class'=>'form-control']); ?>

</div>
<input type="submit" name="Register" value="register">

<?php echo Form::close(); ?>

<hr>


<?php /*<form action="POST">*/ ?>
    <?php /*username: <input type="text" id="name">*/ ?>
    <?php /*password: <input type="password">*/ ?>
    <?php /*<button type ="submit" value="">login</button>*/ ?>
<?php /*</form>*/ ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>