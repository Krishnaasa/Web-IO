<?php $__env->startSection('login'); ?>

    <script src="http://192.168.43.181/jquery-1.11.1.js"></script>

    <script>
        $('#home').hide();
    </script>
    <?php /*<h2>Login</h2>*/ ?>
<?php /*<?php echo Form::open(['url'=>'login']); ?>*/ ?>
    <?php /*<form action="http://localhost/learning-laravel-5/public/articles">*/ ?>
    <?php /*<div>*/ ?>
    <?php /*<input type="text"id ='username'class="form-control">Username</input>*/ ?>
    <?php /*</div>*/ ?>
    <?php /*<input type="password" id ='password'class="form-control">Password</input>*/ ?>
    <?php /*<?php echo Form::label('username',"Username "); ?>*/ ?>
    <?php /*<?php echo Form::text('username',null,['class'=>'form-control']); ?>*/ ?>

<?php /*<div>*/ ?>
    <?php /*<?php echo Form::label('password',"Password "); ?>*/ ?>
    <?php /*<?php echo Form::text('password',null,['class'=>'form-control']); ?>*/ ?>
<?php /*</div>*/ ?>
    <div class='preload login--container'>
        <div class='login--form'>

        <form action="login" method="post" id="setNick" name="setNick">
            <div class='login--username-container'>
            <label>Username</label>
            <input autofocus placeholder='Username' type="text" id="nickname" name="username">
            </div>
            <div class='login--password-container'>
                <label>Password</label>
                <input placeholder='Password' type="password" name="password">
                <button class='js-toggle-login login--login-submit' type="submit" name="Login" value="login" onclick="writeCookie();">Login </button>
            </div>
    <?php /*<input type="submit" name="Login" value="login" onclick="writeCookie();"/>*/ ?>

        </form>
        </div>
    </div>
<?php /*<input type="submit" name="Login" value="login">*/ ?>
<?php /*<?php echo Form::close(); ?>*/ ?>
<script >
function writeCookie()
{
    alert("You need to enable cookies to use our web page fully functioning");
    cookievalue=escape(document.setNick.username.value)+";";
    document.cookie="name="+cookievalue;
    console.log("Setting Cookies : "+"name="+cookievalue);
}
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>