@extends('app')

@section('login')

    <script src="http://localhost/jquery-1.11.1.js"></script>

    <script>
        $('#home').hide();
    </script>
    {{--<h2>Login</h2>--}}
{{--{!! Form::open(['url'=>'login'])!!}--}}
    {{--<form action="http://localhost/learning-laravel-5/public/articles">--}}
    {{--<div>--}}
    {{--<input type="text"id ='username'class="form-control">Username</input>--}}
    {{--</div>--}}
    {{--<input type="password" id ='password'class="form-control">Password</input>--}}
    {{--{!! Form::label('username',"Username ") !!}--}}
    {{--{!! Form::text('username',null,['class'=>'form-control']) !!}--}}

{{--<div>--}}
    {{--{!! Form::label('password',"Password ") !!}--}}
    {{--{!! Form::text('password',null,['class'=>'form-control']) !!}--}}
{{--</div>--}}
    <div class='preload login--container'>
        <div class='login--form'>

        <form action="login" method="post" id="setNick" name="setNick">
            <div class='login--username-container'>
            <label>Username</label>
            <input autofocus placeholder='Username' type="text" id="nickname" name="username">
            </div>
            <div class='login--password-container'>
                <label>Password</label>
                <input placeholder='Password' type="password" name="password">
                <button class='js-toggle-login login--login-submit' type="submit" name="Login" value="login" onclick="writeCookie();">Login </button>
            </div>
    {{--<input type="submit" name="Login" value="login" onclick="writeCookie();"/>--}}

        </form>
        </div>
    </div>
{{--<input type="submit" name="Login" value="login">--}}
{{--{!! Form::close() !!}--}}
<script >
function writeCookie()
{
    alert("You need to enable cookies to use our web page fully functioning");
    cookievalue=escape(document.setNick.username.value)+";";
    document.cookie="name="+cookievalue;
    console.log("Setting Cookies : "+"name="+cookievalue);
}
    </script>
    @stop
