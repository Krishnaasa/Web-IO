@extends('app')

@section('content')
    <head>
        <title>Chat Application</title>
        {{--<script src="https://cdn.socket.io/socket.io-1.2.0.js"></script>--}}
        {{--<script src="http://code.jquery.com/jquery-1.11.1.js"></script>--}}
        <script src="http://localhost/socket.io-1.2.0.js"></script>
        {{--<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/1.4.6/socket.io.min.js"></script>--}}
        <script src="http://localhost/jquery-1.11.1.js"></script>

{{--
Video chat script tags--}}
        {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>--}}
        {{--<script src="https://cdn.pubnub.com/pubnub-3.7.14.min.js"></script>--}}
        {{--<script src="https://cdn.pubnub.com/webrtc/webrtc.js"></script>--}}
        {{--<script src="https://cdn.pubnub.com/webrtc/rtc-controller.js"></script>--}}


        {{--<script  src="{{ URL::asset('chat.js') }}"></script>--}}
        {{--href="{{ URL::asset('assets/css/bootstrap.min.css') }}">--}}
        {{--<link rel='stylesheet' href="{{ URL::asset('/style.css') }}" type="text/css">--}}

        <style>
            #contentWrap{
                display: none;
            }
        </style>
        <div id="overlay" style="position: fixed; width:100%; height: 500%; background: rgba(0, 0, 0, 0.6);"></div>
<script>
    var socket = io('http://localhost:9998');//listens on port 9998
    function switchRoom(room) {
        socket.emit('switchRoom', room);
    }

    $( document ).ready(function() {

        socket.on('updatechat', function (username, data) {

            $('#conversation').show();
            $('#conversation').append('<b>' + username + ':</b> ' + data + '<br>');
            $('#nickWrap').hide();
            $('#groupchat').show();
            $('#contentWrap').show();
            $('#rooms').show();
            $('#conversation').show();
        });

        socket.on('updaterooms', function (rooms, current_room) {
            $('#rooms').empty();
            $.each(rooms, function (key, value) {
                if (value == current_room) {
                    console.log(value);
                    $('#rooms').append('<div>' + value + '</div>');
                }
                else {
                    $('#rooms').append('<div><a href="#" onclick="switchRoom(\'' + value + '\')">' + value + '</a></div>');
                }
            });
        });


        // on load of page
        $(function () {
            // when the client clicks SEND
            $('#datasend').click(function () {
                var message = $('#data').val();
                $('#data').val('');
                // tell server to execute 'sendchat' and send along one parameter
                socket.emit('sendchat', message);
            });

            // when the client hits ENTER on their keyboard
            $('#data').keypress(function (e) {
                if (e.which == 13) {
                    $(this).blur();
                    $('#datasend').focus().click();
                }
            });
        });
    });
</script>
        {{--<script>--}}
            {{--$('#home').hide();--}}

            {{--var socket = io('http://localhost:9998');//listens on port 9998--}}
            {{--$( document ).ready(function()--}}
            {{--{--}}
                {{--$('#video').hide();--}}
                {{--var $nickForm=$('#setNick');--}}
                {{--var $nickBox=$('#nickname');--}}
                {{--var $mesForm=$('#form');--}}
                {{--var $onlineusers=$('#usersdiv');--}}
                {{--var $offlineusers=$('#outdateddiv');--}}
                {{--$('#rooms').hide();--}}
                {{--$('#grpusersdiv').hide();--}}
                {{--$('#group').hide();--}}
                {{--$('#groupchat').hide();--}}
                {{--$nickForm.submit(function(e)--}}
                {{--{ //when new user logs in and clicks submit button,user can send messages--}}
                    {{--e.preventDefault();--}}
                    {{--var allcookies=document.cookie;--}}
                    {{--console.log(allcookies);--}}
                    {{--cookiearray=allcookies.split(';');--}}
                    {{--for(var i=0; i<cookiearray.length; i++){--}}
                        {{--name = cookiearray[i].split('=')[0];--}}
                        {{--value = cookiearray[i].split('=')[1];--}}
                        {{--console.log("Key is: " + i + name + " and Value is : " + value);--}}
{{--//                            console.log($nickBox.val());--}}
                           {{--// console.log(value);--}}
                            {{--if($nickBox.val() == value)--}}
                            {{--{--}}

                                {{--break;--}}
                            {{--}--}}
                    {{--}--}}
                    {{--if($nickBox.val() == value)--}}
                    {{--{--}}
                        {{--console.log("inside ");--}}
                        {{--$('#group').show();--}}
                        {{--socket.emit('adduser', $nickBox.val(), function (data) {--}}
                            {{--console.log("data: "+data);--}}
                            {{--if (data) {--}}
                                {{--$('#rooms').show();--}}
                                {{--$('#conversation').show();--}}
                                {{--console.log("kk");--}}
                                {{--$('#nickWrap').hide();--}}
                                {{--$('#contentWrap').show();--}}
                            {{--}--}}
                        {{--});--}}

                    {{--}--}}
                    {{--$nickBox.val();--}}
                {{--});--}}

                {{--socket.on('usernames',function(data){--}}
                    {{--var html=' ';--}}
                    {{--for(i=0; i<data.length;i++)--}}
                    {{--{--}}
                        {{--//    console.log("len.."+data.length);--}}
                        {{--html+= data[i]+'</br>'--}}
                    {{--}--}}
                    {{--$onlineusers.html(html);--}}
                {{--});--}}
                {{--var x=1;--}}

                {{--socket.on('outdated_users',function(offline_users,data,m){--}}
                    {{--var off_users = ' ';--}}

{{--//                    if (m==2) {--}}
{{--// tarvata chudali--}}
{{--//                        console.log("if part...");--}}
{{--//                    }--}}
{{--//                    else {--}}
{{--//                        var off_users = offline_users;--}}
{{--//                        console.log("else part...." + off_users);--}}
{{--//                    }--}}

                    {{--for (i = 0; i < offline_users.length; i++) {--}}
{{--//                           console.log(offline_users.splice(offline_users[i])+"user being removed");--}}
                        {{--off_users += offline_users[i] + '</br>'--}}
                        {{--// off_users+=data[i]+'</br>'--}}
                    {{--}--}}
                    {{--//}        function outdated();--}}
                    {{--//    socket.broadcast.emit('disconnect',data);--}}
                    {{--//  }--}}
{{--//                            console.log("length.." + offline_users.length);--}}

                    {{--//console.log(offline_users.splice(offline_users.indexOf(socket.nickname)));--}}

                    {{--//  off_users += offline_users[i] + '</br>'--}}
                    {{--$offlineusers.html(off_users);--}}
                {{--});--}}

                {{--socket.on('check',function(offline_users,data){--}}
                    {{--for(i=0;i<offline_users.length;i++) {--}}
                        {{--for (x = 0; x < data.length; x++) {--}}

                            {{--if (offline_users[i] == data[x]) {--}}
                                {{--//console.log(offline_users[i]);--}}
                                {{--console.log(offline_users.splice(offline_users[i]) + "user being removed");--}}
                                {{--offline_users.splice(offline_users[i]);--}}
                                {{--//off_users += offline_users[i] + '</br>--}}
                                {{--// var m=1;--}}
                                {{--socket.emit('checktoo',offline_users);--}}
                                {{--// off_users+=data[i]+'</br>'--}}
                            {{--}--}}
                        {{--}--}}
                    {{--}--}}
                {{--});--}}


                {{--$mesForm.submit(function(e)--}}
                {{--{--}}
                    {{--e.preventDefault();--}}
                    {{--$('#m').keyup(function(e)--}}
                    {{--{--}}
                        {{--var from = $('#nickname').val();--}}
                        {{--var msg = $('#m').val();--}}
                        {{--var too=$('#to').val();--}}
                        {{--//var docs='';--}}

                        {{--if(e.keyCode == 13)--}}
                        {{--{--}}
                            {{--//when user clicks send,client emits "private message" event--}}
                            {{--// and request goes to server which is listening--}}
                            {{--if((msg != '') && (too != ''))--}}
                            {{--{--}}
                                {{--console.log(too);--}}
                                {{--socket.emit('private message',too,from,msg);--}}
                                {{--//socket.emit('oldmessages',too,from,msg);--}}
                                {{--//$('#m').val('');--}}
                            {{--}--}}
                            {{--$('#m').val('').focus();--}}
                            {{--return false;--}}
                        {{--}--}}
                        {{--else--}}
                        {{--{--}}
                            {{--//if the user is still typing ,it emits "notifyUser" event--}}
                            {{--// and request goes to server which is listening--}}
                            {{--socket.emit('notifyUser',too,from);--}}
                        {{--}--}}
                    {{--});--}}
                {{--});--}}

                {{--socket.on('old',function(too,from,msg,docs)--}}
                {{--{--}}
                    {{--//displays the old messages from mongoDB collection--}}
                    {{--console.log("hi old",docs);--}}
                    {{--//for(var i=0;i<docs.length;i++)--}}
                    {{--for(var i=docs.length-1;i>0;i--)--}}
                    {{--{--}}
                        {{--console.log("OOO");--}}
                        {{--if(docs[i].too == too)--}}
                        {{--{--}}
                            {{--console.log("kkkkkk")--}}
                            {{--$('#messages').append('<li>' + docs[i].from + '</b>: ' + docs[i].msg + '</li>');--}}
                        {{--}--}}
                        {{--else if(docs[i].too == from)--}}
                        {{--{--}}
                            {{--console.log("sus cackdsck");--}}
                            {{--$('#messages').append('<li>' + docs[i].from + '</b>: ' + docs[i].msg + '</li>');--}}
                        {{--}--}}
                        {{--//$('#messages').append('<li>' + docs[i].from + '</b>: ' + docs[i].msg + '</li>');--}}
                        {{--//   displayMsg(docs[i]);--}}
                        {{--console.log(docs[i]);--}}
                    {{--}--}}
                {{--});--}}

                {{--//reply--}}
                {{--socket.on('chatMessage', function(too,from, msg)--}}
                {{--{--}}
                    {{--displayMsg(too,from,msg);--}}
                    {{--// $('#messages').append('<li>' + from + '</b>: ' + msg + '</li>');--}}
                {{--});--}}

                {{--function displayMsg(too,from,msg,docs)--}}
                {{--{--}}
                    {{--//  var too=$('#to').val();--}}
                    {{--$('#messages').append('<li>' + from + '</b>: ' + msg + '</li>');--}}
                {{--}--}}

                {{--socket.on('notifyUser', function(too,from){--}}

                    {{--//  var me = socket.nickname;--}}
                    {{--//typ=socket.nickname;--}}
                    {{--//var from = $('#nickname').val();--}}
                    {{--if(from != (socket.nickname)) {--}}
                        {{--console.log('typing');--}}
                        {{--$('#notifyUser').text(from+ ' is typing ...');--}}

                        {{--//$('#messages').text(from + 'hi');--}}
                    {{--}--}}
                    {{--setTimeout(function(){ $('#notifyUser').text(''); }, 10000);;--}}
                {{--});--}}
            {{--});--}}


        {{--</script>--}}
    </head>
    {{--html Code for client side --}}
    <body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="http://localhost/videoscripts/pubnub-3.7.14.min.js"></script>
    <script src="http://localhost/videoscripts/webrtc.js"></script>
    <script src="http://localhost/videoscripts/rtc-controller.js"></script>

    <div class='preload login--container' id ="nickWrap" style="top: 29em;">
        <div class='login--form'>
            <div class='login--username-container'>
                <form id="setNick" name="setNick">
                    <label>Username</label>
                    <input autofocus placeholder='Username'  id = "nickname" type='text'>
                    <button class='js-toggle-login login--login-submit'>Please Re-Enter Your Username </button>
                </form>

            </div>

        </div>
    </div>

    {{--<div id="groupchat">--}}
    {{--<div style="float:left;width:100px;border-right:1px solid black;height:300px;padding:10px;">--}}
        {{--<b>GROUPS</b>--}}
        {{--<div id="rooms"></div>--}}
    {{--</div>--}}
    {{--<div style="float:left;width:300px;height:250px;padding:10px;">--}}
        {{--<div id="conversation"></div>--}}
        {{--<input id="data" style="width:200px;" />--}}
        {{--<input type="button" id="datasend" value="send to group" />--}}
    {{--</div>--}}
    {{--</div>--}}


    <div id="contentWrap">
        <ul id="messages" style=" position: absolute; top:70px; right:41em"></ul>
        <ul id="notifyUser" style="position: fixed; top:29em; right:375px"></ul>
        <form id="form" style=" position: absolute; bottom:4em; right:1em">
            <div>
                <label>To : </label>
                <input type="text" placeholder="reciever's name" id="to" autocomplete="off" style="width:250px"/>
            </div>

            <input type="text" id="m" autocomplete="off"  placeholder="Type your message here.." style="width:700px"/>
            <input type="submit" id="button" value="Send" />
        </form>
        <form name="loginForm" id="login" action="#" style=" position: fixed; bottom:20px; right:5px" >
            <input type="button" name="login_submit" onclick="login();"  value="Click here to initiate call from your side" >
            <input type="button" name="makecall" onclick="makeCall();" value="Make call to your foe">
        </form>

        <p style="position: absolute;margin:0.3em">Users Online : </p><br>
        <div id="usersdiv"style="width: 180px; height: 200px; margin: 1em 0.5em; overflow-y: scroll; border: 4px double; padding: 0 0.5em; position:relative;" >
            <p >User list</p>
        </div>

        </br>
        </br>
        <p style="position:absolute;left:5px;top:250px;">Offline Users: </p>
        <div id="outdateddiv" style="width: 180px; height: 200px; margin: 0 0.5em; overflow-y: scroll; border: 4px double; padding: 0 0.5em ; position:relative;">
            <p>Offline Users</p>
        </div>
        <div id="groupchat" style="position:absolute;left:190px;top:10px">
            <div style="width:100px;height:auto;padding: 0 1em 1em 1em">
            <b>GROUPS</b>
            <div id="rooms" ></div>
            </div>
            <div style="float:left;width:200px;height:250px;padding: 0 1em 1em 1em">
            <div id="conversation" style="margin: 0.5em 0;"></div>
                <form id="roomsform" style=" ; bottom:-19em; left:0px; margin: 1em 0">
                <input type="text" id="data" style="width:200px;" />
                    <br>
            <input type="button" id="datasend" value="send to group" style="max-width: 115px; padding: 0.5em !important;"/>
                    </form>
            </div>
            </div>


        </div>
    <div class="col-md-6" style="margin-top: -19em; margin-left: 29em">
        <span id="vid-box" style="float: right; margin-right: 1em"></span>
    </div>
    <div style="margin-top: -19em; margin-left: 29em">
        <span id="vid-thumb" style="float: left; margin: 1em"></span>
    </div>

    <div id ="video">
        {{--<form name="callForm" id="call" action="#" onsubmit="return makeCall(this);">--}}
            {{--<input type="text" name="number" placeholder="Enter user to dial!" />--}}
            {{--<input type="submit" value="Call"/>--}}
        {{--</form>--}}
        <div id="inCall"> <!-- Buttons for in call features -->
            <button id="end" onclick="end()">End</button>
            <button id="mute" onclick="mute()">Mute</button>
            <button id="pause" onclick="pause()">Pause</button>
        </div>


    </div>
    <script>
        var vid_thumb = document.getElementById("vid-thumb");
        var video_out = document.getElementById("vid-box");

    function login() {
            //var x= sendername();
            //var x= $("#from").val();
            var x=$('#nickname').val();
            console.log("inside login");
//          console.log(video_out);
            console.log(vid_thumb);
            var phone = window.phone = PHONE({
                number        : x || "Anonymous", // listen on username line else Anonymous
                publish_key   : 'pub-c-9c31f97c-ad04-46b6-8997-dbd9e17d8bc6',
                subscribe_key : 'sub-c-3b36d9d2-0649-11e6-a6dc-02ee2ddab7fe',
            });
            var ctrl = window.ctrl = CONTROLLER(phone);
            console.log("hiiiie");
            ctrl.ready(function(){

//                form.username.style.background="#55ff5b"; // Turn input green
//                form.login_submit.hidden="true";	// Hide login button

                ctrl.addLocalStream(vid_thumb);


            });				// Called when ready to receive call
            ctrl.receive(function(session){
                session.connected(function(session){ video_out.appendChild(session.video); });
                console.log("inside receive");
                console.log(video_out);
                session.ended(function(session) { ctrl.getVideoElement(session.number).remove(); });   // Call Ended
            });	// Called on incoming call/call ended
            ctrl.videoToggled(function(session, isEnabled){
                ctrl.getVideoElement(session.number).toggle(isEnabled); // Hide video is stream paused
            });
            ctrl.audioToggled(function(session, isEnabled){
                ctrl.getVideoElement(session.number).css("opacity",isEnabled ? 1 : 0.75); // 0.75 opacity is audio muted
            });
            return false; //prevents form from submitting
        }

        function end(){
            ctrl.hangup();
        }


        function mute(){
            var audio = ctrl.toggleAudio();
            if (!audio) $("#mute").html("Unmute");
            else $("#mute").html("Mute");
        }

        function pause(){
            var video = ctrl.toggleVideo();
            if (!video) $('#pause').html('Unpause');
            else $('#pause').html('Pause');
        }


        function makeCall(){
            //var y =receivername();
            $('#inCall').show();
            console.log("makecall");
            $('#video').show();
            x=$("#to").val();
            console.log(x);
            if (!window.phone) alert("Login First!");
            else phone.dial(x);
            return false;
        }

    </script>
    </body>
    <script src="./hello.js"></script>
@stop
