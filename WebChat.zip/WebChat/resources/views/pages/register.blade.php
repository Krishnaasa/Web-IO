@extends('app')

@section('login')

    {{--<h2>Registeration</h2>--}}
    {{--{!! Form::open(['url'=>'signup'])!!}--}}

    {{--{!! Form::label('username',"Username ") !!}--}}
    {{--{!! Form::text('username',null,['class'=>'form-control']) !!}--}}

    {{--<div>--}}
    {{--{!! Form::label('password',"Password ") !!}--}}
    {{--{!! Form::text('password',null,['class'=>'form-control']) !!}--}}
    {{--</div>--}}
    {{--<div>--}}
    {{--{!! Form::label('email',"Email ") !!}--}}
    {{--{!! Form::text('email',null,['class'=>'form-control']) !!}--}}
    {{--</div>--}}
    {{--<input type="submit" name="Register" value="register">--}}
    {{--<br>--}}
    {{--{!! Form::close() !!}--}}

    <div class='preload login--container'>
        <div class='login--form'>
            <form action="signup" method="post" onsubmit="return validate_pass()" id="signupform">
                <div class='login--password-container'>
                    <label>Username:</label>
                    <input autofocus placeholder='Username' type="text" id="username" name="username"  required>
                    <label>Password:</label>
                    <input autofocus placeholder='Password' type="password" id="password" name="password"  required>
                    <label>Reenter Password</label>
                    <input placeholder='Re-Password' type="password" name="password" id="password1">
                    <label>Email</label>
                    <input type="text" id="email" name="email" placeholder="Your email please"  required>
                    <button class='js-toggle-login login--login-submit' type ="submit" value="register">Register</button>
                </div>
            </form>
        </div>
    </div>
    <script src="http://localhost/jquery-1.11.1.js"></script>

    <script>
        $('#home').hide();

        function validate_pass() {
            var pass1 = document.getElementById('password').value;
            var pass2 = document.getElementById('password1').value;
            var email = document.getElementById('email').value;
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            var count=0;
            if(pass1 != pass2)
            {
                alert("passwords must match!!!Try again");
                count=0;
            }
            else count=count+1;
            if(email.match(mailformat))
            {
                count=count+1;
            }
            else
            {
                alert("Not a valid e-mail address");
                count=0;
            }
            if(count==2){
                alert(hey);
                console.log(count);
                return true;
            }
            else{
                console.log(count);
                return false;
            }
        }

       </script>
@stop