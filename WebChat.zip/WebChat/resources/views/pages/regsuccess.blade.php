@extends('app')
@section('success')
<h2>
    User Successfully Registed
</h2>
    @stop