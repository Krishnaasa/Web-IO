<html>
<head>
    <link rel="icon" type="image/png" href="http://localhost/img/1f436.png" sizes="32x32">
    <title>Web Chat </title>
    <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto+Slab'>
</head>
<style>
html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}body{margin:0}article,aside,details,figcaption,figure,footer,header,main,menu,nav,section,summary{display:block}audio,canvas,progress,video{width: 250px; height: 250px; position: relative}audio:not([controls]){display:none;height:0}progress{vertical-align:baseline}template,[hidden]{display:none}a{background-color:transparent; color: cyan}a:active,a:hover{outline-width:0}abbr[title]{border-bottom:none;text-decoration:underline;text-decoration:underline dotted}b,strong{font-weight:inherit}b,strong{font-weight:bolder}dfn{font-style:italic}h1{font-size:2em;margin:0.67em 0}mark{background-color:#ff0;color:#000}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-0.25em}sup{top:-0.5em}img{border-style:none}svg:not(:root){overflow:hidden}code,kbd,pre,samp{font-family:monospace, monospace;font-size:1em}figure{margin:1em 40px}hr{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;height:0;overflow:visible}button,input,select,textarea{font:inherit;margin:0}optgroup{font-weight:bold}button,input,select{overflow:visible}button,select{text-transform:none}button,[type="button"],[type="reset"],[type="submit"]{cursor:pointer}[disabled]{cursor:default}button,html [type="button"],[type="reset"],[type="submit"]{-webkit-appearance:button}button::-moz-focus-inner,input::-moz-focus-inner{border:0;padding:0}button:-moz-focusring,input:-moz-focusring{outline:1px dotted ButtonText}fieldset{border:1px solid #c0c0c0;margin:0 2px;padding:0.35em 0.625em 0.75em}legend{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;color:inherit;display:table;max-width:100%;padding:0;white-space:normal}textarea{overflow:auto}[type="checkbox"],[type="radio"]{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:0}[type="number"]::-webkit-inner-spin-button,[type="number"]::-webkit-outer-spin-button{height:auto}[type="search"]{-webkit-appearance:textfield}[type="search"]::-webkit-search-cancel-button,[type="search"]::-webkit-search-decoration{-webkit-appearance:none}

* {
margin: 0;
padding: 0;
box-sizing: border-box;
}

html, body {
height: 100%;
background: url("/Chat.png");
font-family: "Roboto Slab", serif;
color: white;
}


label {
display: block;
font-weight: bold;
font-size: small;
text-transform: uppercase;
font-size: 0.7em;
margin-bottom: 0.35em;
}
p{
    display: block;
    font-weight: bold;
    font-size: medium;
    text-transform: uppercase;
    font-size: 1.3em;
    margin-bottom: 0.35em;
}

input[type="text"], input[type="password"] {
width: 100%;
border: none;
padding: 0.5em;
border-radius: 2px;
margin-bottom: 0.5em;
color: #333;
}
input[type="text"]:focus, input[type="password"]:focus {
outline: none;
box-shadow: inset -1px -1px 3px rgba(0, 0, 0, 0.3);
}

button,input[type="button"],input[type="submit"] {
padding-left: 1.5em;
padding-right: 1.5em;
padding-bottom: 0.5em;
padding-top: 0.5em;
border: none;
border-radius: 2px;
background-color: #7E5AF1;
text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.25);
color: white;
box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.45);
}

/*small {
font-size: 1em;
}*/

.login--login-submit {
float: right;
}

.login--container {
width: 600px;
background-color: #F15A5C;
margin: 0 auto;
position: relative;
top: 25%;
}

#inCall{
    position: relative;
    left: 45.5em;
    bottom: 5em;
}


.login--toggle-container .js-toggle-login {
font-size: 4em;
text-decoration: underline;
}

.login--username-container, .login--password-container {
    float: left;
    background-color: #F15A5C;
    width: 50%;
    padding: 0.5em;
    margin-left: 5em;
}

.login--username-container {
float: left;
background-color: #F15A5C;
width: 50%;
padding: 0.5em;
backface-visibility: hidden;
}

.login--active .login--username-container {
transform: perspective(1000px) rotateY(0deg);
background-color: #F15A5C;
}


</style>
<body>

<div id="home" style="padding-top: 1em !important;padding-left: 28em;">
<h1>Welcome to Web-IO's home page</h1>
<a href="signup" style="padding-left: 3em;font-size: 2em;">New user ??<img src="http://localhost/img/1f40c.png" ></a>

    <br>
<a href="login" style="padding-left: 3em;font-size: 2em;">Nah!! Just love being here<img src="http://localhost/img/1f436.png" sizes="64x64"></a>
</div>

@yield('login')
@yield('success')
@yield('content')
<label style="position:fixed;bottom:2px">
    A page where you can chat with your friends and groups within a locality .Heres a chance to say no to your monthly Internet data plans
</label>

</body>

{{--<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">--}}
{{--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.js"></script>--}}
</html>