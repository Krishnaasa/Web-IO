/**
 * Created by krishnaa and bsarmishta on 23/04/16.
 */

$('#home').hide();

var socket = io('http://localhost:9998');//listens on port 9998

var crypto=require('crypto'),
    algorithm='aes-256-ctr',
    password='krishnaa';

function switchRoom(room){
    socket.emit('switchRoom',room);
}
$( document ).ready(function()
{
    $('#video').show();
    var $nickForm=$('#setNick');
    var $nickBox=$('#nickname');
    var $mesForm=$('#form');
    var $onlineusers=$('#usersdiv');
    var $offlineusers=$('#outdateddiv');
    $('#rooms').hide();
    $('#grpusersdiv').hide();
    $('#group').hide();
    $('#groupchat').hide();
    $nickForm.submit(function(e)
    { //when new user logs in and clicks submit button,user can send messages
        e.preventDefault();
        var allcookies=document.cookie;
        console.log(allcookies);
        cookiearray=allcookies.split(';');
        for(var i=0; i<cookiearray.length; i++){
            name = cookiearray[i].split('=')[0];
            value = cookiearray[i].split('=')[1];
            //console.log("Key is: " + i + name + " and Value is : " + value);
         if($nickBox.val() == value)
            {

                break;
            }
         else alert("username incorrect! ReEnter your login username");

        }
        if($nickBox.val() == value)
        {
            console.log("inside ");
            $('#group').show();
            socket.emit('adduser', $nickBox.val(), function (data) {
                console.log("data: "+data);
                if (data) {
                    console.log("kk");
                    $('#nickWrap').hide();
                    $('#groupchat').show();
                    $('#contentWrap').show();
                    $('#rooms').show();
                    $('#conversation').show();

                }
            });

        }
        $nickBox.val();
    });

//    socket.on('updatechat', function (username, data) {
//
//        $('#conversation').append('<b>'+username + ':</b> ' + data + '<br>');
//        $('#nickWrap').hide();
//        $('#groupchat').show();
//        $('#contentWrap').show();
//        $('#rooms').show();
//        $('#conversation').show();
//
//
//    });
//    function switchRoom(room){
//        socket.emit('switchRoom',room);
//    }
//    socket.on('updaterooms', function(rooms, current_room) {
//        $('#rooms').empty();
//        $.each(rooms, function(key, value) {
//            if(value == current_room){
//                $('#rooms').append('<div>' + value + '</div>');
//            }
//            else {
//                $('#rooms').append('<div><a href="#" onclick="switchRoom(\''+value+'\')">' + value + '</a></div>');
//            }
//        });
//    });
//
//
//// on load of page
//    $(function(){
//        // when the client clicks SEND
//        $('#datasend').click( function() {
//            var message = $('#data').val();
//            $('#data').val('');
//            // tell server to execute 'sendchat' and send along one parameter
//            socket.emit('sendchat', message);
//        });
//
//        // when the client hits ENTER on their keyboard
//        $('#data').keypress(function(e) {
//            if(e.which == 13) {
//                $(this).blur();
//                $('#datasend').focus().click();
//            }
//        });
//    });
    socket.on('usernames',function(data){
        var html=' ';
        for(i=0; i<data.length;i++)
        {
            //    console.log("len.."+data.length);
            html+= data[i]+'</br>'
        }
        $onlineusers.html(html);
    });
    var x=1;

    socket.on('outdated_users',function(offline_users,data,m){
        var off_users = ' ';

//                    if (m==2) {
// tarvata chudali
//                        console.log("if part...");
//                    }
//                    else {
//                        var off_users = offline_users;
//                        console.log("else part...." + off_users);
//                    }

        for (i = 0; i < offline_users.length; i++) {
//                           console.log(offline_users.splice(offline_users[i])+"user being removed");
            off_users += offline_users[i] + '</br>'
            // off_users+=data[i]+'</br>'
        }
        //}        function outdated();
        //    socket.broadcast.emit('disconnect',data);
        //  }
//                            console.log("length.." + offline_users.length);

        //console.log(offline_users.splice(offline_users.indexOf(socket.nickname)));

        //  off_users += offline_users[i] + '</br>'
        $offlineusers.html(off_users);
    });

    socket.on('check',function(offline_users,data){
        for(i=0;i<offline_users.length;i++) {
            for (x = 0; x < data.length; x++) {

                if (offline_users[i] == data[x]) {
                    //console.log(offline_users[i]);
                    console.log(offline_users.splice(offline_users[i]) + "user being removed");
                    offline_users.splice(offline_users[i]);
                    //off_users += offline_users[i] + '</br>
                    // var m=1;
                    socket.emit('checktoo',offline_users);
                    // off_users+=data[i]+'</br>'
                }
            }
        }
    });


    $mesForm.submit(function(e)
    {
        e.preventDefault();
        $('#m').keyup(function(e)
        {
            var from = $('#nickname').val();
            var msg = $('#m').val();
            var too=$('#to').val();
            //var docs='';

            if(e.keyCode == 13)
            {
                //when user clicks send,client emits "private message" event
                // and request goes to server which is listening
                if((msg != '') && (too != ''))
                {
                    console.log(too);
                    msg= encrypt(msg);
                    console.log(msg);
                    socket.emit('private message',too,from,msg);
                    //socket.emit('oldmessages',too,from,msg);
                    //$('#m').val('');
                }
                $('#m').val('').focus();
                return false;
            }
            else
            {
                //if the user is still typing ,it emits "notifyUser" event
                // and request goes to server which is listening
                socket.emit('notifyUser',too,from);
            }
        });
    });
    function encrypt(text){

        var cipher = crypto.createCipher(algorithm,password)
        var crypted = cipher.update(text,'utf8','hex')
        crypted += cipher.final('hex');
        return crypted;
    }

    socket.on('old',function(too,from,msg,docs)
    {
        //displays the old messages from mongoDB collection
        console.log("hi old",docs);
        //for(var i=0;i<docs.length;i++)
        for(var i=docs.length-1;i>0;i--)
        {
            console.log("OOO");
            if(docs[i].too == too)
            {
                console.log("kkkkkk")
                $('#messages').append('<li>' + docs[i].from + '</b>: ' + docs[i].msg + '</li>');
            }
            else if(docs[i].too == from)
            {
                console.log("sus cackdsck");
                $('#messages').append('<li>' + docs[i].from + '</b>: ' + docs[i].msg + '</li>');
            }
            //$('#messages').append('<li>' + docs[i].from + '</b>: ' + docs[i].msg + '</li>');
            //   displayMsg(docs[i]);
            console.log(docs[i]);
        }
    });

    //reply
    socket.on('chatMessage', function(too,from, msg)
    {
        msg=decrypt(msg);
        displayMsg(too,from,msg);
        // $('#messages').append('<li>' + from + '</b>: ' + msg + '</li>');
    });
    function decrypt(text){
        var decipher = crypto.createDecipher(algorithm,password)
        var dec = decipher.update(text,'hex','utf8')
        dec += decipher.final('utf8');
        return dec;
    }
    function displayMsg(too,from,msg,docs)
    {
        //  var too=$('#to').val();
        $('#messages').append('<li>' + from + '</b>: ' + msg + '</li>');
    }

    socket.on('notifyUser', function(too,from){

        //  var me = socket.nickname;
        //typ=socket.nickname;
        //var from = $('#nickname').val();
        if(from != (socket.nickname)) {
            console.log('typing');
            $('#notifyUser').text(from+ ' is typing ...');

            //$('#messages').text(from + 'hi');
        }
        setTimeout(function(){ $('#notifyUser').text(''); }, 10000);;
    });
});
//
//
//var vid_thumb = document.getElementById("vid-thumb");
//var video_out = document.getElementById("vid-box");
//
//function login() {
//    //var x= sendername();
//    //var x= $("#from").val();
//    var x=$('#nickname').val();
//    console.log("inside login");
////          console.log(video_out);
//    console.log(vid_thumb);
//    var phone = window.phone = PHONE({
//        number        : x || "Anonymous", // listen on username line else Anonymous
//        publish_key   : 'pub-c-9c31f97c-ad04-46b6-8997-dbd9e17d8bc6',
//        subscribe_key : 'sub-c-3b36d9d2-0649-11e6-a6dc-02ee2ddab7fe',
//    });
//    var ctrl = window.ctrl = CONTROLLER(phone);
//    console.log("hiiiie");
//    ctrl.ready(function(){
//
////                form.username.style.background="#55ff5b"; // Turn input green
////                form.login_submit.hidden="true";	// Hide login button
//
//        ctrl.addLocalStream(vid_thumb);
//
//
//    });				// Called when ready to receive call
//    ctrl.receive(function(session){
//        session.connected(function(session){ video_out.appendChild(session.video); });
//        console.log("inside receive");
//        console.log(video_out);
//        session.ended(function(session) { ctrl.getVideoElement(session.number).remove(); });   // Call Ended
//    });	// Called on incoming call/call ended
//    ctrl.videoToggled(function(session, isEnabled){
//        ctrl.getVideoElement(session.number).toggle(isEnabled); // Hide video is stream paused
//    });
//    ctrl.audioToggled(function(session, isEnabled){
//        ctrl.getVideoElement(session.number).css("opacity",isEnabled ? 1 : 0.75); // 0.75 opacity is audio muted
//    });
//    return false; //prevents form from submitting
//}
//
//function end(){
//    ctrl.hangup();
//}
//
//
//function mute(){
//    var audio = ctrl.toggleAudio();
//    if (!audio) $("#mute").html("Unmute");
//    else $("#mute").html("Mute");
//}
//
//function pause(){
//    var video = ctrl.toggleVideo();
//    if (!video) $('#pause').html('Unpause');
//    else $('#pause').html('Pause');
//}
//
//
//function makeCall(){
//    //var y =receivername();
//    console.log("makecall");
//    x=$("#to").val();
//    console.log(x);
//    if (!window.phone) alert("Login First!");
//    else phone.dial(x);
//    return false;
//}



