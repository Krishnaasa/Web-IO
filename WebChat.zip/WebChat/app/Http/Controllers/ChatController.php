<?php

namespace App\Http\Controllers;
//use Illuminate\Http\Request;
use App\reguser;
//use App\Http\Requests;
use Request;
use Illuminate\Support\Facades\Crypt;
class ChatController extends Controller
{
    public function getlogin()
    {
        return view('pages.signin');
    }
    public function home()
    {
        return view('app');
    }
    public function chatpage()
    {
        return view('pages.chat');
    }

    public function check()
    {
        $count = 1;
        $input = Request::all();
        $x = Request::get('username');
        $salt="DhLp456Fhrt";
        $enc1=$x ^ $salt;
        $y=Request::get('password');
        $enc2=$y ^ $salt;
        //return $enc1;
        // Request::get('password');Request::get('password')
        $val = reguser::where('username', $enc1)->count();
        if ($val > 0) {
            if (reguser::where('password', $enc2)->count() == 1) {
                // return view('pages.chat');
                return redirect('chat');
                //echo "<br>welcome ", $x;
            } else {
                $count = 2;
            }//echo "User doesnt exist";
        } else $count = 2;

        if ($count == 2) {
            //        return redirect('getlogin');
            return view('pages.signin');

        }
        return $input;

    }

    public function signup()
    {
        return view('pages.register');
    }

    public function store()
    {
        $input = Request::all();//Request::get('username')
        //$username=Request::get('username');

        $x=new reguser();
        $new=$x->getname($input);
        reguser::create($new);
        //$input->fill([
          //  'secret' => Crypt::encrypt($request->secret)
        //])->save();
        //return $input;
        //return $new;
        return redirect('home');
    }
}

//    public function store($key,$value){
//        if(in_array($key, $this->encryptable)) {
//            $value = Crypt::encrypt($value);
//        }
//
//            return reguser::store($key, $value);
//        }
//    }

//}
